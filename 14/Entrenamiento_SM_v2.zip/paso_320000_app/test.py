"""Evaluar los pesos de cubo y nave del directorio que contiene este archivo."""
import csv
import ctypes
import time
from collections import deque
from contextlib import ExitStack
from datetime import datetime
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from capturar_juego import GeometryDashCapture
from gd_lector_estado import GDStateReader

PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

#La unión conserva MouseInput para respetar el tamaño de INPUT de Windows
VK_SPACE = 0x20
KEYEVENTF_KEYUP = 0x0002

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput), ("mi", MouseInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", Input_I)]

def press_key():
    #Simula mantener presionada la barra espaciadora
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(VK_SPACE, 0, 0, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def release_key():
    #Simula soltar la barra espaciadora
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.ki = KeyBdInput(VK_SPACE, 0, KEYEVENTF_KEYUP, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(1), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def detener_con_f8():  #Consulta F8 aunque la ventana activa sea el juego.
    estado = ctypes.windll.user32.GetAsyncKeyState(0x77)  #0x77 es el código de F8.
    return bool(estado & 0x8001)  #Detecta si está presionada o hubo una pulsación reciente.


class DQN(nn.Module):
    def __init__(self, input_shape=(4, 84, 84), num_actions=2):
        super(DQN, self).__init__()

        #Capas para procesar los frames
        self.conv = nn.Sequential(
            nn.Conv2d(input_shape[0], 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU()
        )

        #Forma del input
        conv_out_size = self._get_conv_out(input_shape)

        #Conecta capas
        self.fc = nn.Sequential(
            nn.Linear(conv_out_size, 512),
            nn.ReLU(),
            nn.Linear(512, num_actions)
        )

    def _get_conv_out(self, shape):
        o = self.conv(torch.zeros(1, *shape))
        return int(np.prod(o.size()))

    def forward(self, x):
        #Escala valor de pixeles de 0-255 a 0.0-1.0
        x = x.float() / 255.0
        conv_out = self.conv(x).view(x.size()[0], -1)
        return self.fc(conv_out)


def cargar_red(ruta, device):
    red = DQN().to(device)
    pesos = torch.load(ruta, map_location=device, weights_only=True)
    red.load_state_dict(pesos)
    red.requires_grad_(False)
    return red.eval()


def evaluar(captura, lector, elegir, archivo):
    writer = csv.writer(archivo)
    estado = lector.read()
    frame = captura.capture()
    frames = deque([frame] * 4, maxlen=4)
    # Si el juego ya estaba avanzado, controlar hasta la primera reaparición.
    intento_completo = estado["percent"] == 0
    if not intento_completo:
        print("Sincronizando con el siguiente intento completo...")
    intentos = pasos = 0
    record = 0.0
    while not detener_con_f8():
        accion = elegir(frames, estado["vehicle"])
        if accion == 1:
            press_key()
        else:
            release_key()
        time.sleep(1 / 60)
        frames.append(captura.capture())
        siguiente = lector.read()
        if intento_completo:
            pasos += 1
        muerte = siguiente["attempts"] > estado["attempts"]
        victoria = not muerte and siguiente["percent"] >= 100
        if muerte or victoria:
            release_key()
            if intento_completo:
                porcentaje = 100.0 if victoria else estado["percent"]
                intentos += 1
                record = max(record, porcentaje)
                writer.writerow([intentos, pasos, 0.0, porcentaje, record])
                archivo.flush()
                print(f"Intento {intentos} | Pasos: {pasos} | Epsilon: 0.000 | "
                      f"Porcentaje alcanzado: {porcentaje:.3f} % | Máximo: {record:.3f} %")
            if victoria:
                print("Nivel completado. Fin de la evaluación.")
                return
            frame = captura.capture()
            frames = deque([frame] * 4, maxlen=4)
            intento_completo = True
        estado = siguiente
    print("Evaluación detenida con F8.")


def main():
    carpeta = Path(__file__).resolve().parent
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cubo = cargar_red(carpeta / "cubo_model.pth", device)
    nave = cargar_red(carpeta / "nave_model.pth", device)

    def elegir(frames, vehiculo):
        red = nave if vehiculo == 1 else cubo
        entrada = torch.as_tensor(np.stack(frames), device=device).unsqueeze(0)
        return red(entrada).argmax(dim=1).item()

    with ExitStack() as recursos:
        captura = GeometryDashCapture(image_size=(84, 84))
        recursos.callback(captura.close)
        lector = GDStateReader()
        recursos.callback(lector.close)
        recursos.callback(release_key)
        nombre = datetime.now().strftime("datos_testeo_%Y%m%d_%H%M%S_%f.csv")
        archivo = recursos.enter_context((carpeta / nombre).open("x", newline="", encoding="utf-8"))
        print(f"Evaluando {carpeta.name} en {device}. Resultados: {nombre}")
        print("Vuelve al nivel en modo normal. F8 detiene la evaluación.")
        for segundos in range(5, 0, -1):
            print(f"Comienza en {segundos}...")
            time.sleep(1)
        with torch.inference_mode():
            evaluar(captura, lector, elegir, archivo)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Evaluación interrumpida.")

