#Para que funcione en Wine
import os
os.environ["KMP_AFFINITY"] = "disabled"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

#Librerías
import sys
import csv

import numpy as np
from collections import deque
import ctypes
import time
import math

import torch
import torch.nn as nn
import torch.optim as optim
import random

from capturar_juego import GeometryDashCapture
from gd_lector_estado import GDStateReader

#----------------------------------------------------------#
#                   Variables globales                     #
#----------------------------------------------------------#

PERCENT_BUFFER = 10000

BATCH_SIZE = 32
GAMMA = 0.99  # Learning rate, mismo que el paper

TARGET_UPDATE = 1000 #Guardar epoca, mismo que el paper
NUM_EPISODES = 10000
GUARDADOS_POR_SNAPSHOT = 20  # Conservar los pesos cada 500 × 20 decisiones globales

#ID del vehiculo obtenido por el mod
VEHICLE_CUBO = 0
VEHICLE_NAVE = 1

global_steps = 0
global_steps_nave = 0
global_steps_cubo = 0
global_max_percent = 0
global_epocas = 0

#Tunear la convolución a mi GPU
torch.backends.cudnn.benchmark = True

#----------------------------------------------------------#
#                     Apretar botones                      #
#----------------------------------------------------------#

#Código para apretar botones (hacer que salte)
#Utiliza mouse en vez de SPACE porque es más compatible con Wine

#Mouse input
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004

PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput), ("mi", MouseInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", Input_I)]

def press_key():
    #Simula presionar botón izquierdo del mouse
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.mi = MouseInput(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def release_key():
    #Simula dejar de presionar el botón izquierdo del mouse
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.mi = MouseInput(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))



#----------------------------------------------------------#
#                   Función recompensa                     #
#----------------------------------------------------------#

def calcular_reward(estado_actual, estado_anterior, max_percent):

    #Calcula cuanto avanzó
    progreso = estado_actual["percent"] - max_percent

    #Si hay más intentos, murió
    muerte = estado_actual["attempts"] > estado_anterior["attempts"]

    reward = 0
    r = 0

    if muerte:
        reward += -2.0

    if progreso >=3:
        r = int(progreso // 3)
        reward += r

    return reward, muerte, r


#----------------------------------------------------------#
#             Obtener capturas y hacer acción              #
#----------------------------------------------------------#

class GeometryDashEnv:
    def __init__(self):

        #Inicializa recolección de datos con los códigos del Fraik
        self.screen_capture = GeometryDashCapture(image_size=(84, 84))
        self.state_reader = GDStateReader()

        #Para guardar los 4 frames de input en cada paso
        self.frame_stack = deque(maxlen=4)

        #Para guardar info del intento anterior
        self.intentos_anteriores = 0
        self.porcentaje_anterior = 0.0

        #Guarda info sobre el progreso
        self.max_percent = 0.0
        self.visitas_totales = [0] * 101        #Guarda las visitas totales a cada porcentaje hasta el momento
        self.visitas_epoca = [False] * 101   #Guarda si en el paso actual visitó o no (ToF) el porcentaje
        self.ultimo_porcentaje_recompensado = 0

    def step(self, accion):
        #Hacer accion
        if accion == 1:
            press_key()
        else:
            release_key()

        #Delay para que el juego procese el frame (sync con fps del juego)
        target_time = time.perf_counter() + (1 / 60)
        while time.perf_counter() < target_time:
            pass

        #Captura screenshot y lo transforma a 84x84 en escala de grises
        current_frame = self.screen_capture.capture()
        self.frame_stack.append(current_frame)

        #Lee el estado: percent, attempts, vehicle, and is_upside_down
        estado = self.state_reader.read()

        #Diccionario con el estado anterior para calcular el reward
        prev_estado = {
            "attempts": self.intentos_anteriores,
            "percent": self.porcentaje_anterior
        }

        #Actualiza el porcentaje máximo alcanzado
        self.max_percent = max(self.max_percent, estado["percent"])

        #Marca como visitado los porcentajes correspondientes
        current_percent = int(estado['percent'])

        #Sumar las visitas de la época actual
        for p in range(current_percent + 1):
            if not self.visitas_epoca[p]:
                self.visitas_epoca[p] = True
                self.visitas_totales[p] += 1

        #totalvisits = self.visitas_totales[current_percent]

        #Calcular recompensa
        reward, done, ult_perc_rec = calcular_reward(estado, prev_estado, self.ultimo_porcentaje_recompensado)

        self.ultimo_porcentaje_recompensado += (ult_perc_rec * 3)

        #Actualizar estados
        self.intentos_anteriores = estado["attempts"]
        self.porcentaje_anterior = estado["percent"]

        #Formatear estado como numpy array (4, 84, 84)
        state = np.array(self.frame_stack)
        info = estado


        return state, reward, done, info

    def reset(self):

        release_key()

        #Reset estado
        estado = self.state_reader.read()
        self.intentos_anteriores = estado["attempts"]
        self.porcentaje_anterior = estado["percent"]
        self.ultimo_porcentaje_recompensado = 0

        self.visitas_epoca = [False] * 101

        #Llenar frame inicial
        initial_frame = self.screen_capture.capture()
        for _ in range(4):
            self.frame_stack.append(initial_frame)

        return np.array(self.frame_stack), estado

    def close(self):
        #Liberar memoria
        self.screen_capture.close()
        self.state_reader.close()



#----------------------------------------------------------#
#                        Agentes                           #
#----------------------------------------------------------#

class DQN(nn.Module):
    def __init__(self, input_shape=(4, 84, 84), num_actions=2):
        super(DQN, self).__init__()

        #Capas para procesar los frames
        self.conv = nn.Sequential(
            nn.Conv2d(input_shape[0], 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU()
        )

        #Forma del input
        conv_out_size = self._get_conv_out(input_shape)

        #Conecta capas
        self.fc = nn.Sequential(
            nn.Linear(conv_out_size, 512),
            nn.ReLU(),
            nn.Linear(512, num_actions)
        )

    def _get_conv_out(self, shape):
        o = self.conv(torch.zeros(1, *shape))
        return int(np.prod(o.size()))

    def forward(self, x):
        #Escala valor de pixeles de 0-255 a 0.0-1.0
        x = x.float() / 255.0
        conv_out = self.conv(x).view(x.size()[0], -1)
        return self.fc(conv_out)



#----------------------------------------------------------#
#                        Acción                            #
#----------------------------------------------------------#

#Elección epsilon-greedy basado en tipo de vehículo
def elegir_accion(estado, vehicle_id, epsilon):

    if random.random() < epsilon:
        return random.randint(0, 1) #Acción random

    estado_tensor = torch.FloatTensor(estado).unsqueeze(0).to(device)

    with torch.no_grad():
        if vehicle_id == VEHICLE_NAVE:
            q_values = nave_net(estado_tensor)
        else:
            #Usar cubo si no se sabe cuál es
            q_values = cubo_net(estado_tensor)

    return q_values.max(1)[1].item() #Retorna acción con mayor Q-value



#----------------------------------------------------------#
#                           DDQL                           #
#----------------------------------------------------------#

def opti_model(primary_net, target_net, optimizer, replay_buffer):

    #Verifica que se tienen suficientes samples
    if len(replay_buffer) < BATCH_SIZE:
        return

    #Muestrea los frames de manera uniforme
    batch = random.sample(replay_buffer, BATCH_SIZE)

    #Batch con formato PyTorch
    states = torch.FloatTensor(np.array([t[0] for t in batch])).to(device)
    actions = torch.LongTensor([t[1] for t in batch]).view(-1, 1).to(device)
    rewards = torch.FloatTensor([t[2] for t in batch]).to(device)
    next_states = torch.FloatTensor(np.array([t[3] for t in batch])).to(device)
    dones = torch.FloatTensor([t[4] for t in batch]).to(device)

    #Calcula Q(s, a, \theta)
    current_q_values = primary_net(states).gather(1, actions).squeeze(1)

    #DDQL para Y
    #La red primaria calcula \max Q^*(s', a') eligiendo "la mejor acción"
    next_actions = primary_net(next_states).max(1)[1].view(-1, 1)

    #Red objetivo evalúa la acción elegida
    with torch.no_grad():
        next_q_values = target_net(next_states).gather(1, next_actions).squeeze(1)

    # Y = r(a,s) + \eta * Q_target(s', a')
    #si murió (done == 1), la esperanza de la recompenza futura es 0
    expected_q_values = rewards + (GAMMA * next_q_values * (1 - dones))

    #Calcula pérdida J(\theta)
    loss = nn.MSELoss()(current_q_values, expected_q_values)

    #Optimizar
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()



#----------------------------------------------------------#
#                      Training Loop                       #
#----------------------------------------------------------#

def train_agents(env):
    state, info = env.reset()
    vehicle = info["vehicle"]

    #Usar los pasos cargados (=0 si no hay)
    steps_done = global_steps
    steps_done_nave = global_steps_nave
    steps_done_cubo = global_steps_cubo
    saved_epocas = global_epocas

    #Cargar el max_percent guardado en el env
    env.max_percent = global_max_percent

    this_percent = 0


    with open('datos_entrenamiento.csv', mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        csv_buffer = []

        for epoca in range(NUM_EPISODES):

            if this_percent == 100:
                break

            this_percent = 0

            while True:

                #Calcula epsilon (exploración-explotación tradeoff) para cada vehículo
                if vehicle == VEHICLE_NAVE:
                    epsilon = max(0.01, 1.0 - (steps_done_nave / 1000000))
                else:
                    epsilon = max(0.01, 1.0 - (steps_done_cubo / 1000000))

                epsilon_save.append([this_percent, epsilon])


                #Elige acción basado en el vehículo activo
                accion = elegir_accion(state, vehicle, epsilon)


                #Hace un paso
                next_state, reward, done, next_info = env.step(accion)
                next_vehicle = next_info["vehicle"]

                if done == False:
                    this_percent = next_info["percent"]


                #Guarda la transicion en el buffer correcto
                transicion = (state, accion, reward, next_state, done)
                if vehicle == VEHICLE_CUBO:
                    cubo_replay_buffer.append(transicion)
                    opti_model(cubo_net, cubo_target_net, cubo_optimizer, cubo_replay_buffer)
                elif vehicle == VEHICLE_NAVE:
                    nave_replay_buffer.append(transicion)
                    opti_model(nave_net, nave_target_net, nave_optimizer, nave_replay_buffer)

                #Dio un paso
                if vehicle == VEHICLE_NAVE:
                    steps_done_nave += 1
                else:
                    steps_done_cubo += 1

                steps_done = steps_done_cubo + steps_done_nave
                epoc = epoca+saved_epocas

                #Siguiente estado
                state = next_state
                vehicle = next_vehicle

                #Actualización de la red objetivo cada C=TARGET_UPDATE pasos
                if steps_done % TARGET_UPDATE == 0:
                    cubo_target_net.load_state_dict(cubo_net.state_dict())
                    nave_target_net.load_state_dict(nave_net.state_dict())

                    #Guarda redes al disco
                    torch.save(cubo_net.state_dict(), "cubo_model.pth")
                    torch.save(nave_net.state_dict(), "nave_model.pth")

                    # Guardar los contadores de pasos
                    with open("steps_cubo.txt", "w") as f:
                        f.write(str(steps_done_cubo))
                    with open("steps_nave.txt", "w") as f:
                        f.write(str(steps_done_nave))
                    # Guardar % máximo alcnazado
                    with open("max_perc.txt", "w") as f:
                        f.write(str(env.max_percent))
                    # Guardar las épocas realizadas
                    with open("epocas.txt", "w") as f:
                        f.write(str(epoc))
                    # Guardar datos de entrenamiento
                    for row in csv_buffer:
                        writer.writerow(row)
                    csv_buffer.clear()
                    file.flush()

                    print(f"\n---Red actualizada en paso {steps_done}---")

                if steps_done % (GUARDADOS_POR_SNAPSHOT * TARGET_UPDATE) == 0:
                    torch.save(cubo_net.state_dict(), f"cubo_model_{steps_done}.pth")
                    torch.save(nave_net.state_dict(), f"nave_model__{steps_done}.pth")


                if done:
                    print(f"\nÉpoca {epoc} | Pasos: {steps_done} | Epsilon: {epsilon:.3f} | Porcentaje alcanzado: {this_percent:.3f} % |  Porcentaje máximo   : {env.max_percent:.3f} %")
                    csv_buffer.append([epoc, steps_done, epsilon, this_percent, env.max_percent])

                    state, info = env.reset()
                    vehicle = info["vehicle"]
                    break

                if this_percent == 100:
                    cubo_target_net.load_state_dict(cubo_net.state_dict())
                    nave_target_net.load_state_dict(nave_net.state_dict())

                    #Guarda redes al disco
                    torch.save(cubo_net.state_dict(), "cubo_model.pth")
                    torch.save(nave_net.state_dict(), "nave_model.pth")

                    # Guardar los contadores de pasos
                    with open("steps_cubo.txt", "w") as f:
                        f.write(str(steps_done_cubo))
                    with open("steps_nave.txt", "w") as f:
                        f.write(str(steps_done_nave))
                    # Guardar % máximo alcnazado
                    with open("max_perc.txt", "w") as f:
                        f.write(str(env.max_percent))
                    # Guardar las épocas realizadas
                    with open("epocas.txt", "w") as f:
                        f.write(str(epoc))
                    # Guardar datos de entrenamiento
                    for row in csv_buffer:
                        writer.writerow(row)
                    csv_buffer.clear()
                    file.flush()

                    break





#----------------------------------------------------------#
#                        Ejecutar                          #
#----------------------------------------------------------#
epsilon_save = []

if __name__ == "__main__":

    #-------------------------------------------------#
    #              Inicializar Redes                  #
    #-------------------------------------------------#
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


    #Cubo
    cubo_net = DQN().to(device)
    cubo_target_net = DQN().to(device)
    cubo_target_net.load_state_dict(cubo_net.state_dict())
    cubo_optimizer = optim.Adam(cubo_net.parameters(), lr=1e-4)
    cubo_replay_buffer = deque(maxlen=50000)

    #Nave
    nave_net = DQN().to(device)
    nave_target_net = DQN().to(device)
    nave_target_net.load_state_dict(nave_net.state_dict())
    nave_optimizer = optim.Adam(nave_net.parameters(), lr=1e-4)
    nave_replay_buffer = deque(maxlen=50000)

    #-------------------------------------------------#
    #        Importar entrenamiento previo            #
    #-------------------------------------------------#
    print("\nBuscando entrenamiento previo...\n")

    if os.path.exists("cubo_model.pth"):
        cubo_net.load_state_dict(torch.load("cubo_model.pth"))
        cubo_target_net.load_state_dict(cubo_net.state_dict())
        print("Modelo del cubo cargado exitosamente.")

    if os.path.exists("nave_model.pth"):
        nave_net.load_state_dict(torch.load("nave_model.pth"))
        nave_target_net.load_state_dict(nave_net.state_dict())
        print("Modelo de la nave cargado exitosamente.")

    if os.path.exists("steps_nave.txt"):
        with open("steps_nave.txt", "r") as f:
            global_steps_nave = int(f.read())
        print(f"\nRetomando entrenamiento desde el paso {global_steps_nave}")
    if os.path.exists("steps_cubo.txt"):
        with open("steps_cubo.txt", "r") as f:
            global_steps_cubo = int(f.read())
        print(f"\nRetomando entrenamiento desde el paso {global_steps_cubo}")
    if os.path.exists("epocas.txt"):
        with open("epocas.txt", "r") as f:
            global_epocas = int(f.read())
        print(f"Retomando entrenamiento desde la época {global_epocas}")
    if os.path.exists("max_perc.txt"):
        with open("max_perc.txt", "r") as f:
            global_max_percent = float(f.read())
        print(f"Porcentaje máximo alcanzado {global_max_percent}\n")


    #dummy_input = torch.zeros(1, 4, 84, 84).to(device)

    #cubo_net_traced = torch.jit.trace(cubo_net, dummy_input)
    #nave_net_traced = torch.jit.trace(nave_net, dummy_input)

    #-------------------------------------------------#
    #                    Entrenar                     #
    #-------------------------------------------------#

    print("\nIniciando entorno...\n")
    env = GeometryDashEnv()

    print("¡Cambia a la ventana de Geometry Dash ahora!")
    for i in range(5, 0, -1):
        print(f"Comienza en {i}...")
        time.sleep(1)

    start = time.perf_counter()

    try:
        print("\nIniciando entrenamiento...")
        train_agents(env)
    except KeyboardInterrupt:
        print("\nEntrenamiento interrumpido por el usuario.")
    finally:
        with open('epsilons.csv', 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerows(epsilon_save)      # Write data rows
        env.close()
        end = (time.perf_counter() - start)
        print(f'Tiempo total = {end} s')
        print("Entorno cerrado y memoria liberada.")
