Esta carpeta es para entrenar la red con las siguientes características:

Input: tensor con un stack de 4 frames de 84x84 pixeles, frames escalados de 0-255 a 0.0-1.0.

3 capas de convolución:
 - Capa 1: Input a 32 canales, usando kernel de 8x8 y paso 4.
 - Capa 2: 32 canales a 64 canales, usando kernel de 4x4 y paso 2.
 - Capa 3: 64 canales a 64 canales, usando kernel de 3x3 y paso 1.

Capa completamente conectada: output de convolución conectadas con una capa de 512 neuronas.

Capa de output (completamente conectada):  capa de 512 neuronas conectadas a las 2 neuronas de output (saltar o no saltar).

Algoritmo: DDQL

Agentes expertos independientes: un agente para el cubo y uno para la nave   .

Optimización: Adam con learning rate de 1e-4; cálculo de error con MSELoss.

Elección de acción: epsilon-greedy (exploración-explotación tradeoff), con: epsilon = max(0.05, 1.0 - (steps_done / 100000))

Learning rate: GAMMA = 0.99

Función de recompensa:

    pesos = {
            "multiplicador_avanza": 10.0,   #Recompensa por avanzar
            "castigo_muerte": -5.0,         #Penalización por morir
            "bonus_sobrevive": 0.01         #Recompensa por sobrevivir el frame
        }

    #Calcula cuanto avanzó
    progreso = max(0, estado_actual["percent"] - estado_anterior["percent"])

    #Si hay más intentos, murió
    muerte = estado_actual["attempts"] > estado_anterior["attempts"]

    if muerte:
        return pesos["castigo_muerte"], True

    #Recompensa total
    reward = (progreso * pesos["multiplicador_avanza"]) + pesos["bonus_sobrevive"]


Config:

    NUM_EPISODES = 5000 (Cantidad de épocas a realizar)
    TARGET_UPDATE = 500 (Cada cuantos pasos guarda)
    BATCH_SIZE = 32 (Cantidad mínima de frames necesarios para samplear 4)





Para correr en Linux (Debian/Ubuntu con Wine), usar el comando:

>WINEDEBUG=-all WINEPREFIX=~/.wine wine python train1.py

Para correr en Windows, usar el comando:

>python train1.py [? Benja pon acá el comando que usas para correrlo]


************************

Entrenado de corrido sin checkpoints.
