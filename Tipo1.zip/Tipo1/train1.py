#Para que funcione en Wine
import os
os.environ["KMP_AFFINITY"] = "disabled"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

#Librerías
import sys
import csv

import numpy as np
from collections import deque
import ctypes
import time

import torch
import torch.nn as nn
import torch.optim as optim
import random

from capturar_juego import GeometryDashCapture
from gd_lector_estado import GDStateReader



#----------------------------------------------------------#
#                     Apretar botones                      #
#----------------------------------------------------------#

#Código para apretar botones (hacer que salte)
#Utiliza mouse en vez de SPACE porque es más compatible con Wine

PUL = ctypes.POINTER(ctypes.c_ulong)
class KeyBdInput(ctypes.Structure):
    _fields_ = [("wVk", ctypes.c_ushort), ("wScan", ctypes.c_ushort),
                ("dwFlags", ctypes.c_ulong), ("time", ctypes.c_ulong),
                ("dwExtraInfo", PUL)]

#Mouse input
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004

class MouseInput(ctypes.Structure):
    _fields_ = [("dx", ctypes.c_long), ("dy", ctypes.c_long),
                ("mouseData", ctypes.c_ulong), ("dwFlags", ctypes.c_ulong),
                ("time", ctypes.c_ulong), ("dwExtraInfo", PUL)]

class Input_I(ctypes.Union):
    _fields_ = [("ki", KeyBdInput), ("mi", MouseInput)]

class Input(ctypes.Structure):
    _fields_ = [("type", ctypes.c_ulong), ("ii", Input_I)]

def press_key():
    #Simula presionar botón izquierdo del mouse
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.mi = MouseInput(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))

def release_key():
    #Simula dejar de presionar el botón izquierdo del mouse
    extra = ctypes.c_ulong(0)
    ii_ = Input_I()
    ii_.mi = MouseInput(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, ctypes.pointer(extra))
    x = Input(ctypes.c_ulong(0), ii_)
    ctypes.windll.user32.SendInput(1, ctypes.pointer(x), ctypes.sizeof(x))



#----------------------------------------------------------#
#                   Función recompensa                     #
#----------------------------------------------------------#

def calcular_reward(estado_actual, estado_anterior):

    #Pesos de la recompensa
    pesos = {
            "multiplicador_avanza": 10.0,   #Recompensa por avanzar
            "castigo_muerte": -5.0,         #Penalización por morir
            "bonus_sobrevive": 0.01         #Recompensa por sobrevivir el frame
        }

    #Calcula cuanto avanzó
    progreso = max(0, estado_actual["percent"] - estado_anterior["percent"])

    #Si hay más intentos, murió
    muerte = estado_actual["attempts"] > estado_anterior["attempts"]

    if muerte:
        return pesos["castigo_muerte"], True

    #Recompensa total
    reward = (progreso * pesos["multiplicador_avanza"]) + pesos["bonus_sobrevive"]

    return reward, False



#----------------------------------------------------------#
#             Obtener capturas y tomar acción              #
#----------------------------------------------------------#

class GeometryDashEnv:
    def __init__(self):

        #Inicializa recolección de datos con los códigos del Fraik
        self.screen_capture = GeometryDashCapture(image_size=(84, 84))
        self.state_reader = GDStateReader()

        self.frame_stack = deque(maxlen=4)
        self.intentos_anteriores = 0
        self.porcentaje_anterior = 0.0

    def step(self, accion):
        #Hacer accion
        if accion == 1:
            press_key()
        else:
            release_key()

        #Delay para que el juego procese el frame (sync con fps del juego)
        time.sleep(1/60)

        #Captura screenshot y lo transforma a 84x84 en escala de grises
        current_frame = self.screen_capture.capture()
        self.frame_stack.append(current_frame)

        #Lee el estado: percent, attempts, vehicle, and is_upside_down
        estado = self.state_reader.read()

        #Diccionario con el estado anterior para calcular el reward
        prev_estado = {
            "attempts": self.intentos_anteriores,
            "percent": self.porcentaje_anterior
        }

        #Calcular recompensa
        reward, done = calcular_reward(estado, prev_estado)

        #Actualizar estados
        self.intentos_anteriores = estado["attempts"]
        self.porcentaje_anterior = estado["percent"]

        #Formatear estado como numpy array (4, 84, 84)
        state = np.array(self.frame_stack)
        info = estado

        return state, reward, done, False, info

    def reset(self):

        release_key()

        #Reset estado
        estado = self.state_reader.read()
        self.intentos_anteriores = estado["attempts"]
        self.porcentaje_anterior = estado["percent"]

        #Llenar frame inicial
        initial_frame = self.screen_capture.capture()
        for _ in range(4):
            self.frame_stack.append(initial_frame)

        return np.array(self.frame_stack), estado

    def close(self):
        #Liberar memoria
        self.screen_capture.close()
        self.state_reader.close()



#----------------------------------------------------------#
#                        Agentes                           #
#----------------------------------------------------------#

class DQN(nn.Module):
    def __init__(self, input_shape=(4, 84, 84), num_actions=2):
        super(DQN, self).__init__()

        #Capas para procesar los frames
        self.conv = nn.Sequential(
            nn.Conv2d(input_shape[0], 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU()
        )

        #Forma del input
        conv_out_size = self._get_conv_out(input_shape)

        #Conecta capas
        self.fc = nn.Sequential(
            nn.Linear(conv_out_size, 512),
            nn.ReLU(),
            nn.Linear(512, num_actions)
        )

    def _get_conv_out(self, shape):
        o = self.conv(torch.zeros(1, *shape))
        return int(np.prod(o.size()))

    def forward(self, x):
        #Escala valor de pixeles de 0-255 a 0.0-1.0
        x = x.float() / 255.0
        conv_out = self.conv(x).view(x.size()[0], -1)
        return self.fc(conv_out)

#-------------------------------------------------------------------#

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

#Cubo
cubo_net = DQN().to(device)
cubo_target_net = DQN().to(device)
cubo_target_net.load_state_dict(cubo_net.state_dict())
cubo_optimizer = optim.Adam(cubo_net.parameters(), lr=1e-4)
cubo_replay_buffer = deque(maxlen=50000)

#Nave
nave_net = DQN().to(device)
nave_target_net = DQN().to(device)
nave_target_net.load_state_dict(nave_net.state_dict())
nave_optimizer = optim.Adam(nave_net.parameters(), lr=1e-4)
nave_replay_buffer = deque(maxlen=50000)

#ID del vehiculo obtenido por el mod
VEHICLE_CUBO = 0
VEHICLE_NAVE = 1


#-------------------------------------------------------------------#

#Importar entrenamiento previo

print("\nBuscando entrenamiento previo...\n")
if os.path.exists("cubo_model.pth"):
    cubo_net.load_state_dict(torch.load("cubo_model.pth"))
    cubo_target_net.load_state_dict(cubo_net.state_dict())
    print("Modelo del cubo cargado exitosamente.")

if os.path.exists("nave_model.pth"):
    nave_net.load_state_dict(torch.load("nave_model.pth"))
    nave_target_net.load_state_dict(nave_net.state_dict())
    print("Modelo de la nave cargado exitosamente.")

#-------------------------------------------------------------------#

#Elección epsilon-greedy basado en tipo de vehículo
def elegir_accion(estado, vehicle_id, epsilon):

    if random.random() < epsilon:
        return random.randint(0, 1) #Acción random

    estado_tensor = torch.FloatTensor(estado).unsqueeze(0).to(device)

    with torch.no_grad():
        if vehicle_id == VEHICLE_CUBO:
            q_values = cubo_net(estado_tensor)
        elif vehicle_id == VEHICLE_NAVE:
            q_values = nave_net(estado_tensor)
        else:
            #Usar cubo si no se sabe cuál es
            q_values = cubo_net(estado_tensor)

    return q_values.max(1)[1].item() #Retorna acción con mayor Q-value



#----------------------------------------------------------#
#                        Loop DDQL                         #
#----------------------------------------------------------#

BATCH_SIZE = 32
GAMMA = 0.99  # Learning rate, mismo que el paper

def opti_model(primary_net, target_net, optimizer, replay_buffer):

    #Verifica que se tienen suficientes samples
    if len(replay_buffer) < BATCH_SIZE:
        return

    #Muestrea los frames de manera uniforme
    batch = random.sample(replay_buffer, BATCH_SIZE)

    #Batch con formato PyTorch
    states = torch.FloatTensor(np.array([t[0] for t in batch])).to(device)
    actions = torch.LongTensor([t[1] for t in batch]).view(-1, 1).to(device)
    rewards = torch.FloatTensor([t[2] for t in batch]).to(device)
    next_states = torch.FloatTensor(np.array([t[3] for t in batch])).to(device)
    dones = torch.FloatTensor([t[4] for t in batch]).to(device)

    #Calcula Q(s, a, \theta)
    current_q_values = primary_net(states).gather(1, actions).squeeze(1)

    #DDQL para Y
    #La red primaria calcula \max Q^*(s', a') eligiendo "la mejor acción"
    next_actions = primary_net(next_states).max(1)[1].view(-1, 1)

    #Red objetivo evalúa la acción elegida
    with torch.no_grad():
        next_q_values = target_net(next_states).gather(1, next_actions).squeeze(1)

    # Y = r(a,s) + \eta * Q_target(s', a')
    #si murió (done == 1), la esperanza de la recompenza futura es 0
    expected_q_values = rewards + (GAMMA * next_q_values * (1 - dones))

    #Calcula pérdida J(\theta)
    loss = nn.MSELoss()(current_q_values, expected_q_values)

    #Optimizar
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

#-------------------------------------------------------------------#

TARGET_UPDATE = 500 #Guardar epoca, mismo que el paper
NUM_EPISODES = 5000

#Cargar pasos si existen
global_steps = 0
global_max_percent = 0
global_epocas = 0

if os.path.exists("steps.txt"):
    with open("steps.txt", "r") as f:
        global_steps = int(f.read())
    print(f"\nRetomando entrenamiento desde el paso {global_steps}")
if os.path.exists("epocas.txt"):
    with open("epocas.txt", "r") as f:
        global_epocas = int(f.read())
    print(f"Retomando entrenamiento desde la época {global_epocas}")
if os.path.exists("max_perc.txt"):
    with open("max_perc.txt", "r") as f:
        global_max_percent = float(f.read())
    print(f"Porcentaje máximo alcanzado {global_max_percent}\n")



def train_agents(env):
    state, info = env.reset()
    vehicle = info["vehicle"]

    #Usar los pasos cargados (=0 si no hay)
    steps_done = global_steps
    max_percent = global_max_percent
    saved_epocas = global_epocas
    this_percent = 0

    with open('datos_entrenamiento.csv', mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)

        csv_buffer = []

        for epoca in range(NUM_EPISODES):
            while True:
                #Calcula epsilon (exploración-explotación tradeoff)
                epsilon = max(0.05, 1.0 - (steps_done / 100000))

                #Elige acción basado en el vehículo activo
                accion = elegir_accion(state, vehicle, epsilon)

                #Hace un paso
                next_state, reward, done, truncated, next_info = env.step(accion)
                next_vehicle = next_info["vehicle"]

                if done == False:
                    this_percent = next_info["percent"]

                if next_info["percent"] > max_percent:
                    max_percent = next_info["percent"]

                #Guarda la transicion en el buffer correcto
                transicion = (state, accion, reward, next_state, done)
                if vehicle == VEHICLE_CUBO:
                    cubo_replay_buffer.append(transicion)
                    opti_model(cubo_net, cubo_target_net, cubo_optimizer, cubo_replay_buffer)
                elif vehicle == VEHICLE_NAVE:
                    nave_replay_buffer.append(transicion)
                    opti_model(nave_net, nave_target_net, nave_optimizer, nave_replay_buffer)

                #Siguiente estado
                state = next_state
                vehicle = next_vehicle
                steps_done += 1

                epoc = epoca+saved_epocas

                #Actualización de la red objetivo cada C=TARGET_UPDATE pasos
                if steps_done % TARGET_UPDATE == 0:
                    cubo_target_net.load_state_dict(cubo_net.state_dict())
                    nave_target_net.load_state_dict(nave_net.state_dict())

                    #Guarda redes al disco
                    torch.save(cubo_net.state_dict(), "cubo_model.pth")
                    torch.save(nave_net.state_dict(), "nave_model.pth")

                    # Guardar el contador de pasos
                    with open("steps.txt", "w") as f:
                        f.write(str(steps_done))
                    # Guardar % máximo alcnazado
                    with open("max_perc.txt", "w") as f:
                        f.write(str(max_percent))
                    # Guardar las épocas realizadas
                    with open("epocas.txt", "w") as f:
                        f.write(str(epoc))
                    # Guardar datos de entrenamiento
                    for row in csv_buffer:
                        writer.writerow(row)
                    csv_buffer.clear()
                    file.flush()

                    print(f"\n---Red actualizada en paso {steps_done}---")

                if done:
                    print(f"\nÉpoca {epoc} | Pasos: {steps_done} | Epsilon: {epsilon:.3f} | Porcentaje alcanzado: {this_percent:.3f} % |  Porcentaje máximo   : {max_percent:.3f} %")
                    csv_buffer.append([epoc, steps_done, epsilon, this_percent, max_percent])

                    state, info = env.reset()
                    vehicle = info["vehicle"]
                    break



#----------------------------------------------------------#
#                        Ejecutar                          #
#----------------------------------------------------------#


if __name__ == "__main__":

    print("\nIniciando entorno...\n")
    env = GeometryDashEnv()

    print("¡Cambia a la ventana de Geometry Dash ahora!")
    for i in range(5, 0, -1):
        print(f"Comienza en {i}...")
        time.sleep(1)

    try:
        print("\nIniciando entrenamiento...")
        train_agents(env)
    except KeyboardInterrupt:
        print("\nEntrenamiento interrumpido por el usuario.")
    finally:
        env.close()
        print("Entorno cerrado y memoria liberada.")
